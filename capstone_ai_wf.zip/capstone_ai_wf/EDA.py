#!/usr/bin/env python
"""
collection of functions for the final case study solution - EDA
"""

import os
import sys
import re
import shutil
import time
import pickle
from collections import defaultdict
from datetime import datetime
import numpy as np
import pandas as pd
from IPython.display import Image
import seaborn as sns;from matplotlib import pyplot as plt
from ingestion import fetch_ts_wrapper

from IPython.display import display, Markdown, Latex

import plotly.graph_objects as go
import plotly.express as px
from plotly.offline import init_notebook_mode, iplot
#from plotly.offline import download_plotlyjs, init_notebook_mode, plot, iplot
import plotly.graph_objs as go
#init_notebook_mode(connected=False)
from plotly.subplots import make_subplots

def missing_zero_values_table(df,dtcol='date'):
        negtive_val = (df.select_dtypes(include='number') < 0).astype(int).sum(axis=0)
        zero_val = (df == 0).astype(int).sum(axis=0)
        mis_val = df.isnull().sum()
        negtive_val_percent = 100 * negtive_val / len(df)
        Zero_val_percent = 100 * zero_val / len(df)
        mis_val_percent = 100 * df.isnull().sum() / len(df)
        mz_table = pd.concat([negtive_val,negtive_val_percent,zero_val, Zero_val_percent,mis_val, mis_val_percent], axis=1)
        mz_table = mz_table.rename(
        columns = {0 : 'Negtive Values',1 : 'Negtive Values Ratio',2 : 'Zero Values',3 : 'Zero Ratio', 4 : 'Missing Values', 5 : 'Missing Ratio'})
        mz_table['Total Zero Missing Values'] =  + mz_table['Negtive Values'] + mz_table['Zero Values'] + mz_table['Missing Values']
        mz_table['% Total Zero Missing Values'] = 100 * mz_table['Total Zero Missing Values'] / len(df)
        mz_table['Data Type'] = df.dtypes
        mz_table = mz_table[ mz_table['% Total Zero Missing Values']>0 ].sort_values('Missing Ratio', ascending=False).round(1) # [   mz_table.iloc[:,1] != 0  ]
        
        print ("Basic Info about the selected dataframe : ") #+ str(df.shape[1]) + " columns and " + str(df.shape[0]) + " Rows.\n")
        print("{}".format("*"*45))
        display(df.set_index(dtcol).info(verbose=True))
        #print('\n')
        
      
        print("There are " + str(mz_table.shape[0]) +   " columns that have Negative/missing/Zero values.")
        print("{}".format("*"*50))
        #         mz_table.to_excel('D:/sampledata/missing_and_zero_values.xlsx', freeze_panes=(1,0), index = False)

        display(mz_table.head(100))
        print('\n')
        #####
        #df_orig['invoice_date'].unique()
        print("TS-date '{}' column info:\n{}".format(dtcol,"*"*50))
        print('Overal days of data: ',len(pd.date_range(start = df[dtcol].min(), end = df[dtcol].max() )))
        print('missing dates counts: ',len(pd.date_range(start = df[dtcol].min(), end = df[dtcol].max() ).difference(df[dtcol])))
        print('missing dates %age: ',round(len(pd.date_range(start = df[dtcol].min(), end = df[dtcol].max() ).difference(df[dtcol])) / len(pd.date_range(start = df[dtcol].min(), end = df[dtcol].max() )) *100,1) ,'%')

        print('missing dates : ',(pd.date_range(start = df[dtcol].min(), end = df[dtcol].max() ).difference(df[dtcol])))
        return mz_table

def data_qc(df,dtcol='date'):
    missing_zero_values_df=missing_zero_values_table(df,dtcol)
    print("Duplicate Summary\n{}".format("-"*35))
    duplicate_rows = df.duplicated()
    print("{} duplicate rows".format(np.where(duplicate_rows==True)[0].size))
    print('Number of unique rows : ',df[~duplicate_rows].shape[0])


def cleaning_df(df,dupl_revmove=True,negtive_remove_cols=[],cleaning_display=True):
    if dupl_revmove:
        print("Duplicate Rows Cleaning\n{}".format("-"*35)) if cleaning_display==True else None
        duplicate_rows = df.duplicated()
        if True in duplicate_rows:
            df = df[~duplicate_rows]
        print("Removed {} duplicate rows".format(np.where(duplicate_rows==True)[0].size))  if cleaning_display==True else None
        print('Number of unique rows : ',df.shape[0])  if cleaning_display==True else None
    for ncl in negtive_remove_cols:
        print("Negative Values Summary\n{}".format("-"*35))  if cleaning_display==True else None
        
        print('Removing {} rows where "{}" have Negatiive values'.format(df[df[ncl]<0].shape[0],ncl ) )  if cleaning_display==True else None
        df=df[df[ncl]>=0]
        #print(df.shape)
    return df

#==========================================================================================

IMAGE_DIR = os.path.join(".","visualization_images")

def save_fig(fig_id,filename, tight_layout=True, image_path=IMAGE_DIR,plotly_plt=False):
    """
    save the image as png file in the image directory
    """
    
    ## Check the data directory
    if not os.path.exists(image_path):
        os.makedirs(image_path)
    
    path = os.path.join(image_path, filename + ".png")
    print("...saving figure", path)
    if plotly_plt:
        iplot(fig_id, filename=path,image='png')
    else:
        if tight_layout:
            plt.tight_layout()
        plt.savefig(path, format='png', dpi=300)

def engineer_features(df,training=True):
    """
    for any given day the target becomes the sum of the next days revenue
    for that day we engineer several features that help predict the summed revenue
    
    the 'training' flag will trim data that should not be used for training
    when set to false all data will be returned
    """

    ## extract dates
    dates = df['date'].values.copy()
    dates = dates.astype('datetime64[D]')

    ## engineer some features
    eng_features = defaultdict(list)
    previous =[7, 14, 28, 70]  #[7, 14, 21, 28, 35, 42, 49, 56, 63, 70]
    y = np.zeros(dates.size)
    for d,day in enumerate(dates):

        ## use windows in time back from a specific date
        for num in previous:
            current = np.datetime64(day, 'D') 
            prev = current - np.timedelta64(num, 'D')
            mask = np.in1d(dates, np.arange(prev,current,dtype='datetime64[D]'))
            eng_features["previous_{}".format(num)].append(df[mask]['revenue'].sum())

        ## get get the target revenue    
        plus_30 = current + np.timedelta64(30,'D')
        mask = np.in1d(dates, np.arange(current,plus_30,dtype='datetime64[D]'))
        y[d] = df[mask]['revenue'].sum()

        ## attempt to capture monthly trend with previous years data (if present)
        start_date = current - np.timedelta64(365,'D')
        stop_date = plus_30 - np.timedelta64(365,'D')
        mask = np.in1d(dates, np.arange(start_date,stop_date,dtype='datetime64[D]'))
        eng_features['previous_year'].append(df[mask]['revenue'].sum())

        ## add some non-revenue features
        minus_30 = current - np.timedelta64(30,'D')
        mask = np.in1d(dates, np.arange(minus_30,current,dtype='datetime64[D]'))
        eng_features['recent_invoices'].append(df[mask]['unique_invoices'].mean())
        eng_features['recent_views'].append(df[mask]['total_views'].mean())

    X = pd.DataFrame(eng_features)
    ## combine features in to df and remove rows with all zeros
    X.fillna(0,inplace=True)
    mask = X.sum(axis=1)>0
    X = X[mask]
    y = y[mask]
    dates = dates[mask]
    X.reset_index(drop=True, inplace=True)

    if training == True:
        ## remove the last 30 days (because the target is not reliable)
        mask = np.arange(X.shape[0]) < np.arange(X.shape[0])[-30]
        X = X[mask]
        y = y[mask]
        dates = dates[mask]
        X.reset_index(drop=True, inplace=True)
    
    return(X,y,dates)



def plot_dates_gap(x,y1,y2,inf=True):
    fig, ax = plt.subplots(figsize=(18, 5))
    if inf:
        plot = sns.lineplot(
            ax=ax
            ,  x=x, y=y1
            , color='blue'
            #, hue=df_orig_daily_asf_D["price"].isna().cumsum()
            #, palette=["blue"]*sum(df_orig_daily_asf_D["price"].isna())
            , markers=True
            , legend='brief', label=y1.name
        )
        #print('y2-inf=ture')
        if y2 is not None and not y2.empty:
            #print('y2')
            ax2 = plt.twinx()
            plot1 = sns.lineplot(
                ax=ax2
                , x=x, y=y2
                #, hue=y2.isna().cumsum(), markers=True
                , color='red'
                , legend='brief', label=y2.name
            )
            ax2.legend(loc='upper right')
            ax.legend(loc='upper left')
    else: # performance wise not good
        plot = sns.lineplot(
            ax=ax
            ,  x=x, y=y1
            , hue=y1.isna().cumsum()
            #, color='blue'
            #, palette=["blue"]*sum(y1.isna())*2
            , markers=True
            , legend=False #'brief', label='price'
        )
        #print('y2-inf=false')
        if y2 is not None and not y2.empty:
            #print('y2')
            ax2 = plt.twinx()
            plot1 = sns.lineplot(
                ax=ax2
                , x=x, y=y2
                , hue=y2.isna().cumsum()
                , markers=True
                #, color='red'
                #, legend='brief', label='views'
            )
            ax2.legend(loc='upper right')
            ax.legend(loc='upper left')

    plt.show()    
    save_fig(fig_id=fig,filename='plot_dates_gap', tight_layout=True, image_path=IMAGE_DIR,plotly_plt=False)                                
    #return None

def weekly_monthy_boxplot(x,y,w_m='W'):
    if w_m=='W':
        cats = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
        fig, ax = plt.subplots(figsize=(18, 5))
        plot = sns.boxplot(
            ax=ax
            ,  x=x.dt.strftime("%A"), y=y,order=cats
        )
        plt.show()
        save_fig(fig_id=plot,filename='weekly_monthy_boxplot_'+y.name+'_'+w_m, tight_layout=True, image_path=IMAGE_DIR,plotly_plt=False)                                
    elif  w_m=='M':
        fig, ax = plt.subplots(figsize=(18, 5))
        plot = sns.boxplot(
            ax=ax
            ,  x=x.dt.month, y=y
        )
        plt.show()
        save_fig(fig_id=plot,filename='weekly_monthy_boxplot_'+y.name+'_'+w_m, tight_layout=True, image_path=IMAGE_DIR,plotly_plt=False)                                
    else:
        None


def top_grp_plot(df,grp='country',topfield='price',top=10):
    df=df.groupby([grp])[topfield].sum().reset_index().sort_values(topfield,ascending=False).head(top)
    tot=df[topfield].sum()
    df['percentage_of_tot']=df[topfield]/tot*100
    fig=px.bar(data_frame=df,y=grp,x=topfield,orientation='h',color=topfield, #color_continuous_scale=px.colors.sequential.Viridis 
            color_continuous_scale='RdBu',text='percentage_of_tot')
    fig.update_traces(texttemplate='%{text:.2f}%', textposition='auto')
    fig.update_layout(uniformtext_minsize=8, uniformtext_mode='hide',
                                yaxis={'title': None,'autorange':'reversed'},
                                xaxis={'title': None, 'categoryorder': 'total ascending'})
    #save_fig("Top10")
    save_fig(fig_id=fig,filename='top10', tight_layout=True, image_path=IMAGE_DIR,plotly_plt=False)                                
    return fig

def top_two_yaxis_bar_plot(df,grp='country',topfieldx1='price',topfieldx2='times_viewed',top=10):
    df1=df.groupby([grp])[topfieldx1,topfieldx2].sum().reset_index().sort_values(topfieldx1,ascending=False).head(top)
    #df2=df.groupby([grp])[topfieldx2].sum().reset_index().sort_values(topfieldx2,ascending=False).head(top)
    tot=df1[topfieldx1].sum()
    df1['percentage_of_tot_1']=df1[topfieldx1]/tot*100

    tot=df1[topfieldx2].sum()
    df1['percentage_of_tot_2']=df1[topfieldx2]/tot*100
    fig = make_subplots(rows=1, cols=2, shared_yaxes=True,
                        vertical_spacing=0, horizontal_spacing=0,)
    fig.add_trace(
        go.Bar(name=topfieldx1, y=df1[grp], x=df1[topfieldx1],
                xaxis='x2', offsetgroup=2, orientation='h',text=df1['percentage_of_tot_1']),
        row=1, col=1)
    #fig.add_trace(
    #    go.Bar(name='Imp/%GDP', y=country['Country'], x=country['Imp_2019'],
    #            xaxis='x2', offsetgroup=3, orientation='h'),
    #    row=1, col=1)
    fig.add_trace(
        go.Bar(name=topfieldx2,y=df1[grp], x=df1[topfieldx2],
                xaxis='x', offsetgroup=1, orientation='h', marker_color='green',text=df1['percentage_of_tot_2']),
        row=1, col=2)

    fig.update_layout(barmode='group',
                        # showticklabels=True, automargin=True
                        yaxis=dict(autorange="reversed",
                                    side='left', zeroline=False,),
                        xaxis=dict(autorange="reversed", tickangle=0,  automargin=True  # ,title='Exp/Imp - % GDP'
                                    ),
                        xaxis2=dict(tickangle=0, automargin=True,  # title='GDP / captia'
                                    ),
                        legend=dict(yanchor="bottom", y=1.02, xanchor="left", x=0.5, orientation='h'))
    fig.update_traces(texttemplate='%{text:.2f}%', textposition='auto')
    fig.update_layout(margin={'l': 10, 'b': 10, 't': 10,
                                'r': 0}, hovermode='closest',width=1100)
    #save_fig("Top10_2xaxis")                                
    save_fig(fig_id=fig,filename='Top10_2xaxis', tight_layout=True, image_path=IMAGE_DIR,plotly_plt=False)
    return fig

def dist_plot_num_features(df):
    # Convert DF to long FORM then use this
    dfm = df.melt(var_name='columns')    
    g = sns.FacetGrid(dfm, col='columns',sharex=False,sharey=False)
    g = (g.map(sns.distplot, 'value'))
    #save_fig("dist_plot_num_features") 
    save_fig(fig_id=g,filename='dist_plot_num_features', tight_layout=True, image_path=IMAGE_DIR,plotly_plt=False)
    return g

def monthly_grp_bar_plot(df,y,grp='country',xaxis_dt='invoice_date'):
    #nxtpy=nxtpy.set_index('nxtpy')
    #fig = px.bar(df, x=df.index.strftime("%Y/%m/%d") , y='Sum',barmode="group",color="Category") 
    #fig = px.bar(nxtpy, x='' , y='Sum',barmode="group",color="Category")
    #from pylab import rcParams
    #rcParams['figure.figsize'] = 19,6
    df_orig_m=df.groupby([grp,pd.Grouper(key=xaxis_dt, freq='M')]).sum().reset_index().sort_values(['country','invoice_date','price'])
    #df_orig_m=df_orig_m[df_orig_m['country']!='United Kingdom']
    fig = px.bar(data_frame=df_orig_m,
                            x=xaxis_dt, y=y,  # trendline='ols', #lowess
                            # marginal_x='box',marginal_y='box'
                            color=grp,  # size='bal',
                            barmode="stack",
                            # facet_row='CCY.'
                            #text='pre',
                            color_discrete_sequence=px.colors.qualitative.Prism_r,width=1100,
                            # px.colors.sequential.Plasma_r,
                            )

    fig.update_xaxes(title='',#rangebreaks=[dict(values=dt_breaks)] ,
                    #gridcolor='grey',
                    tickangle=0,
                    #ticks="outside",
                    #dtick="Q1",
                    #tickformat="%b\n%Y",
                    #tickmode= 'auto',
                    #nticks=len(nxtpy['nxtpy']),
                    #tickmode= 'linear',
                    tick0= df_orig_m[xaxis_dt].iloc[0],
                    dtick='M1',
                    showspikes=True,spikethickness=2,
                    spikedash="dot",
                    spikecolor="#999999",
                    spikemode="across",linecolor="#BCCCDC",
                    tickformat = '%b \n<br>%Y',
                    #tickvals= [2020, 2040],
                    #ticktext = pd.to_datetime(grothqtr['YQtr'])#[t1 for t1,t2 in grothqtr['YQtr'].str.split("-")]
    )

    #save_fig("monthly_grp_bar_plot") 
    save_fig(fig_id=fig,filename='monthly_grp_bar_plot', tight_layout=True, image_path=IMAGE_DIR,plotly_plt=False)
    return fig

def corr_plot_num_features(df,title,num_features,ord):    
    corrmat = df.corr()
    k = len(num_features) #number of variables for heatmap
    cols = corrmat.nlargest(k, ord)[ord].index
    cm = np.corrcoef(df[cols].values.T)
    sns.set(font_scale=1.25)
    hm = sns.heatmap(cm, cbar=True, annot=True, square=True, fmt='.2f', annot_kws={'size': 10}, yticklabels=cols.values, xticklabels=cols.values).set_title(title)
    #save_fig("correlations")
    save_fig(fig_id=hm,filename='correlations_'+title, tight_layout=True, image_path=IMAGE_DIR,plotly_plt=False)
    return hm

def create_all_plots(ts_all):
    figtop=top_grp_plot(df=ts_all['orig']   ,grp='country',topfield='price',top=10)
    figtop.show() # file saving issue

    fig=top_two_yaxis_bar_plot(df=ts_all['orig'],grp='country',topfieldx1='price',topfieldx2='times_viewed',top=10)
    fig.show() # file saving issue

    dist_plot_num_features(ts_all['all'].loc[:,~ts_all['all'].columns.isin(['year_month','date'])])
        
    fig=monthly_grp_bar_plot(df=ts_all['orig'][['country','invoice_date','price','times_viewed']],y='price',grp='country',xaxis_dt='invoice_date')
    fig.show() # file saving issue

    # file saving issue for below
    weekly_monthy_boxplot(x=ts_all['all']['date'],y=ts_all['all']['unique_invoices'],w_m='M')
    weekly_monthy_boxplot(x=ts_all['all']['date'],y=ts_all['all']['unique_invoices'],w_m='W')

    weekly_monthy_boxplot(x=ts_all['all']['date'],y=ts_all['all']['unique_streams'],w_m='M')
    weekly_monthy_boxplot(x=ts_all['all']['date'],y=ts_all['all']['unique_streams'],w_m='W')

    weekly_monthy_boxplot(x=ts_all['all']['date'],y=ts_all['all']['revenue'],w_m='M')
    weekly_monthy_boxplot(x=ts_all['all']['date'],y=ts_all['all']['revenue'],w_m='W')

    weekly_monthy_boxplot(x=ts_all['all']['date'],y=ts_all['all']['total_views'],w_m='M')
    weekly_monthy_boxplot(x=ts_all['all']['date'],y=ts_all['all']['total_views'],w_m='W')

    temp=ts_all['all'].copy()
    temp['revenue_inf']=ts_all['all']["revenue"].replace(0,np.inf)
    temp['total_views_inf']=ts_all['all']["total_views"].replace(0,np.inf)
    plot_dates_gap(x=temp['date'],y1=temp['revenue_inf'],y2=temp['total_views_inf'],inf=True) # file saving issue
    del temp

    for key in ts_all.keys():
        if key!='orig':
            fig=plt.figure()
            corr_plot_num_features(ts_all[key] ,ord='revenue',title=key ,num_features = ["purchases","unique_invoices","unique_streams","total_views","revenue"])
            fig.show()

#==========================================================================================

def data_qc_cum_cleaning_func(ts_all,train_prod='T',df_cleaning=False,clean=False,qc_display=True,cleaning_display=True):
      
    for key,item in ts_all.items():        
            if df_cleaning:
                print('\nDATA QUALITY CHECKS for dataframe after cleaning: {}\n{}'.format(key,"="*55),'\n' ) if qc_display==True else None
                 #revenue
                if key=='orig':
                    item=cleaning_df(item,dupl_revmove=True,negtive_remove_cols=['price'],cleaning_display=cleaning_display) 
                else:
                    item=cleaning_df(item,dupl_revmove=True,negtive_remove_cols=['revenue'],cleaning_display=cleaning_display) 
                ts_all[key]=item
            print('\nDATA QUALITY CHECKS for dataframe: {}\n{}'.format(key,"="*55),'\n' ) if df_cleaning==False and qc_display==True else None
            if qc_display:
                if key=='orig':
                    data_qc(item,'invoice_date')
                else:
                    data_qc(item,'date')             
    return ts_all


if __name__ == "__main__":
    run_start = time.time()
    #print("\nArguments passed:",sys.argv[1], end = " ")
    
    if len(sys.argv)!=3:
        print('\nTwo CLI arrugments required') 
        sys.exit(1)
    if sys.argv[1] not in ['T','P']:
        print('\nnot a valid CLI arrugment')
        sys.exit(1)
    df_cleaning_v=False
    try:
        if sys.argv[2]=='True':
            df_cleaning_v=True            
    except:
        print('error in arugment')
    #print('loading.......')    
    ts_all = fetch_ts_wrapper(train_prod='T',clean=False)
    print('cleaning and peforming basic dataQality checks.......')
    ts_all=data_qc_cum_cleaning_func(ts_all,train_prod=sys.argv[1],df_cleaning=df_cleaning_v,qc_display=True,cleaning_display=True)   

    m, s = divmod(time.time()-run_start,60)
    h, m = divmod(m, 60)
    print("\n\n..............load and QC time:", "%d:%02d:%02d"%(h, m, s))
