import time,os,re,csv,sys,uuid,joblib
from datetime import date
from collections import defaultdict
import numpy as np
import pandas as pd
from sklearn import svm
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.pipeline import Pipeline

from sklearn import ensemble
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.metrics import classification_report


from logger import update_predict_log, update_train_log
from ingestion import fetch_ts_wrapper
from EDA import data_qc_cum_cleaning_func,save_fig
from DataEngineering import engineer_features

import matplotlib.pyplot as plt
IMAGE_DIR = os.path.join(".","visualization_images")

from sklearn.model_selection import learning_curve
from sklearn.model_selection import ShuffleSplit
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
#from sklearn.linear_model import SGDRegressor
from sklearn.model_selection import GridSearchCV
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor#, AdaBoostRegressor
from sklearn.metrics import mean_squared_error

import warnings
warnings.filterwarnings("ignore", category=FutureWarning)

## model specific variables (iterate the version and note with each change)
MODEL_DIR = "models"
MODEL_VERSION = 0.1
MODEL_VERSION_NOTE = "supervised learning model for time-series"


def get_preprocessor():
    """
    return the preprocessing pipeline
    """

    ## preprocessing pipeline
    numeric_features = ["previous_7","previous_14","previous_28","previous_70","previous_year","recent_invoices","recent_views"] # "purchases",['age', 'num_streams']
    numeric_transformer = Pipeline(steps=[('imputer', SimpleImputer(strategy='mean')),
                                          ('scaler', StandardScaler())])

    #categorical_features = ['country', 'subscriber_type']
    #categorical_transformer = Pipeline(steps=[('imputer', SimpleImputer(strategy='constant', fill_value='missing')),
    #                                          ('onehot', OneHotEncoder(handle_unknown='ignore'))])

    preprocessor = ColumnTransformer(transformers=[('num', numeric_transformer, numeric_features),
                                                   #('cat', categorical_transformer, categorical_features)
                                                   ])


    return(preprocessor)




def _model_train(df,tag,test=False):
    rs=42
    """
    example funtion to train model
    
    The 'test' flag when set to 'True':
        (1) subsets the data and serializes a test version
        (2) specifies that the use of the 'test' log file 
    """


    ## start timer for runtime
    time_start = time.time()
    
    X,y,dates = engineer_features(df)

    ## build models
    regressor_names = ["RF", "GB"]
    
    regressors = (
                  RandomForestRegressor(random_state=rs),
                  GradientBoostingRegressor(random_state=rs)
                  )
    
    params = [
        {"reg__n_estimators":[10,30,50],
         "reg__max_features":[3,4,5],
         "reg__bootstrap":[True, False]},
        {"reg__n_estimators":[10,30,50],
         "reg__max_features":[3,4,5],
         "reg__learning_rate":[1, 0.1, 0.01, 0.001]}
        ]
    


    if test:
        n_samples = int(np.round(0.3 * X.shape[0]))
        subset_indices = np.random.choice(np.arange(X.shape[0]),n_samples,
                                          replace=False).astype(int)
        mask = np.in1d(np.arange(y.size),subset_indices)
        y=y[mask]
        X=X[mask]
        dates=dates[mask]
        
    ## Perform a train-test split
    print('Perform a train-test split')
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25,
                                                        shuffle=True, random_state=42)
    
    ## train models
    models = {}
    total = len(regressor_names)
    for iteration, (name,regressor,param) in enumerate(zip(regressor_names, regressors, params)):
        
        #if verbose:
        if 1==1:
            end = "" if (iteration+1) < total else "\n"
            print("\r...training model: {}/{}".format(iteration+1,total), end=end)
        
        pipe = Pipeline(steps=[("scaler", StandardScaler()),
                               ("reg", regressor)])
        
        grid = GridSearchCV(pipe, param_grid=param, 
                            scoring="neg_mean_squared_error",
                            cv=5, n_jobs=-1, return_train_score=True)
        
        grid.fit(X_train, y_train)
        models[name] = grid, grid.best_estimator_["reg"].get_params()
    
    
    ## evaluation on the validation set
    val_scores = []
    for key, model in models.items():
        y_pred = model[0].predict(X_test)
        rmse = np.sqrt(mean_squared_error(y_pred, y_test))
        val_scores.append(rmse)
        
    ## select best model
    bm = regressor_names[np.argmin(val_scores)]
    opt_model, params = models[bm]
    
    vocab = {
             "RF":"Random Forest",
             "GB":"Gradient Boosting"
             }
    
    if 1==1:
        print("...best model:{}".format(vocab[bm]))

    ## retrain best model on the the full dataset
    opt_model.fit(X, y)

    ## Check the data directory
    model_path=MODEL_DIR
    if not os.path.exists(model_path):
        os.makedirs(model_path)

    if 1==1:
        saved_model = os.path.join(model_path,"test-{}-model-{}.joblib".format(tag,re.sub("\.","_",str(MODEL_VERSION))))
    else:
        saved_model = os.path.join(model_path,"prod-{}-model-{}.joblib".format(tag,re.sub("\.","_",str(MODEL_VERSION))))

    ## save the best model
    joblib.dump(opt_model, saved_model)
    

    m, s = divmod(time.time()-time_start, 60)
    h, m = divmod(m, 60)
    runtime = "%03d:%02d:%02d"%(h, m, s)
    print('Execution time: ',runtime)
    ## update log
    update_train_log(tag,(str(dates[0]),str(dates[-1])),{'rmse':max(val_scores)},runtime,
                     vocab[bm]+' :: '+str(MODEL_VERSION), MODEL_VERSION_NOTE,test=test )
    #tag.upper(),vocab[bm],{'rmse':max(val_scores)},runtime,MODEL_VERSION, MODEL_VERSION_NOTE, dev=dev, verbose=verbose)                     
  

def model_train(data_dir,test=False):
    """
    function to train model given a df
    
    'mode' -  can be used to subset data essentially simulating a train
    """
    
    if not os.path.isdir(MODEL_DIR):
        os.mkdir(MODEL_DIR)

    if test:
        print("... test flag on")
        print("...... subsetting data")
        print("...... subsetting countries")
        
    ## fetch time-series formatted data
    ##############################################ts_data = fetch_ts(data_dir)
    ts_all = fetch_ts_wrapper(train_prod='T',clean=False)
    ts_data = data_qc_cum_cleaning_func(ts_all,train_prod='T',df_cleaning=True,qc_display=False,cleaning_display=False)
    ts_data = { key: ts_data[key] for key in ts_data.keys() if key != 'orig'}

    ## train a different model for each data sets
    for country,df in ts_data.items():        
        if test and country not in ['all','united_kingdom']:
            continue
        print('Model Training for : ',country)
        _model_train(df,country,test=test)
    
def model_load(prefix='sl',data_dir=None,training=True):
    """
    example funtion to load model
    
    The prefix allows the loading of different models
    """

    if not data_dir:
        data_dir = os.path.join("data","cs-train")
    
    models = [f for f in os.listdir(os.path.join(".","models")) if re.search(prefix,f)]

    if len(models) == 0:
        raise Exception("Models with prefix '{}' not found, did you train?".format(prefix))

    all_models = {}
    for model in models:
        #print('model: ', model)
        all_models[re.split("-",model)[1]] = joblib.load(os.path.join(".","models",model))

    ## load data
    ##############ts_data = fetch_ts(data_dir)
    ts_all = fetch_ts_wrapper(train_prod='T',clean=False)
    ts_data = data_qc_cum_cleaning_func(ts_all,train_prod='T',df_cleaning=True,qc_display=False,cleaning_display=False)
    ts_data = { key: ts_data[key] for key in ts_data.keys() if key != 'orig'}

    all_data = {}
    for country, df in ts_data.items():
        df = clean_data(df)
        X,y,dates = engineer_features(df,training=training)
        dates = np.array([str(d) for d in dates])
        all_data[country] = {"X":X,"y":y,"dates": dates}
        
    return(all_data, all_models)
    
def clean_data(df):
    revenue = df['revenue']
    
    if df.empty:
        return(df)
    
    # without negative revenue
    mask = revenue < 0
    df.at[mask, 'revenue'] = np.nan

    # without quantile range outliers
    mask = revenue.between(revenue.quantile(.0), revenue.quantile(0.85)) 
    df.at[~mask, 'revenue'] = np.nan

    mask = revenue.notna()
    median = np.median(df[mask]['revenue'])

    df['revenue'].fillna(median, inplace = True)
    
    return(df)

def model_predict(country,year,month,day,all_models=None,all_data=None,test=False):
    """
    example funtion to predict from model
    """

    ## start timer for runtime
    time_start = time.time()

    ## load model if needed
    if not all_models:
        #all_data,all_models = model_load(training=False)
        all_data, all_models = model_load(prefix='test',training=False)
    
    ## input checks
    if country not in all_models.keys():
        raise Exception("ERROR (model_predict) - model for country '{}' could not be found".format(country))

    for d in [year,month,day]:
        if re.search("\D",d):
            raise Exception("ERROR (model_predict) - invalid year, month or day")
    
    ## load data
    model = all_models[country]
    data = all_data[country]

    ## check date
    target_date = "{}-{}-{}".format(year,str(month).zfill(2),str(day).zfill(2))
    # print(target_date)

    if target_date not in data['dates']:
        raise Exception("ERROR (model_predict) - date {} not in range {}-{}".format(target_date,
                                                                                    data['dates'][0],
                                                                                    data['dates'][-1]))
    date_indx = np.where(data['dates'] == target_date)[0][0]
    query = data['X'].iloc[[date_indx]]
    
    #print(query)

    ## sainty check
    if data['dates'].shape[0] != data['X'].shape[0]:
        raise Exception("ERROR (model_predict) - dimensions mismatch")

    ## make prediction and gather data for log entry
    y_pred = model.predict(query)
    print('y_pred: ',y_pred)

    ## metadata
    print("\nMETADATA")
    #print("...result {}".format(y_pred))
    for key, item in all_models.items():
        print("...label:{}, algorithm:{}".format(key,type(item.best_estimator_["reg"]).__name__) )
    
    

    m, s = divmod(time.time()-time_start, 60)
    h, m = divmod(m, 60)
    runtime = "%03d:%02d:%02d"%(h, m, s)

    ## update predict log
    update_predict_log(country,y_pred,None,target_date,
                       runtime, MODEL_VERSION, test=test)
    
    return({'y_pred':y_pred}) 

if __name__ == "__main__":

    """
    basic test procedure for model.py
    """ 
    training=False   
    if len(sys.argv)==1:
        training=True
    elif len(sys.argv)==2:
        print(sys.argv[1])
        if sys.argv[1] not in ['True','False']:
            print('\nnot a valid CLI arrugment')
            sys.exit(1)
    else:
        print('\nCLI arrugment invalid') 
        sys.exit(1)
   
    run_start = time.time()
    if training==True:
        ## train the model
        print("TRAINING MODELS")
        data_dir = os.path.join("..","data","cs-train")
        model_train(data_dir,test=True)

    ## load the model
    print("LOADING MODELS")
    all_data, all_models = model_load(prefix='test')
    print("... models loaded: ",",".join(all_models.keys()))

    ## test predict
    country='all'
    year='2018'
    month='01'
    day='05'
    print('\nTest Prediction for inputs: \ncountry : ',country,'\nyear: ',year,'\nmonth: ',month,'\nday: ',day)
    result = model_predict(country,year,month,day,all_models=all_models,all_data=all_data)
    print('\nPrediction result: ',result)

    m, s = divmod(time.time()-run_start,60)
    h, m = divmod(m, 60)
    print("\nOverall execution time: ", "%d:%02d:%02d"%(h, m, s))
