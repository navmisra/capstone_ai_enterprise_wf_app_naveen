#!/usr/bin/env python
"""
model tests
"""


import unittest

## import model specific functions and variables
from model_capstone import *

class ModelTest(unittest.TestCase):
    """
    test the essential functionality
    """
        
    def test_01_train(self):
        """
        test the train functionality
        """
        print('test the train functionality')

        ## train the model
        model_train(os.path.join("..","data","cs-train"),test=True)
        print('model_train test - training completed')
        saved_model = os.path.join("models","test-netherlands-model-0_1.joblib")
        print('saved_model: ',saved_model)
        self.assertTrue(os.path.exists(saved_model))

    def test_02_load(self):
        """
        test the load functionality
        """
        print('\ntest the load functionality')
                        
        ## train the model
        all_data, all_models = model_load(prefix='test')
        
        for tag, model in all_models.items():
            self.assertTrue("predict" in dir(model))
            self.assertTrue("fit" in dir(model))

        #model = all_models['netherlands']
        #print('model=\n',model)
        #self.assertTrue('predict' in dir(model))
        #self.assertTrue('fit' in dir(model))

       
    def test_03_predict(self):
        """
        test the predict function input
        """
        print('\ntest the predict function input')

        ## ensure that a list can be passed        
        result = model_predict(country='netherlands',year='2018',month='08',day='01',test=True)
        y_pred = result['y_pred']
        print('unit test pridict result: ', y_pred )
        self.assertTrue(y_pred >= 0.0)

          
### Run the tests
if __name__ == '__main__':
    unittest.main()